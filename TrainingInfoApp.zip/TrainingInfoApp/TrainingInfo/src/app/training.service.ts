import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http'
import { Training } from './training.model';

@Injectable({
  providedIn: 'root'
})
export class TrainingService {

  // URL of WebAPI
  // Enable CORS in WEB API
  baseURL : string = 'http://localhost:19385/api'

  formData : Training;

  // get all training details in this list in order to display
  list : Training[];

  constructor(private http:HttpClient) { }

  // Get Training Details by issuing Get Request to WebAPI
  getAllTrainings(){
    this.http.get(this.baseURL + '/Training')
    .toPromise().then(res => this.list = res as Training[]);
  }

  // Post new training information to Web API so that it could be saved to DB
  postTrainingDetail(formData : Training){
    return this.http.post(this.baseURL + '/Training', formData).subscribe(data => {
      alert(data);
      // Get Training Details after adding new Data
      this.getAllTrainings();
    },
    (err: HttpErrorResponse) => {
      if (err.error instanceof Error) {
        alert("Error occured : " + err.error.message);
      } else {
        alert("Error occured : " + err.error.message);
      }
    });
  }
}
