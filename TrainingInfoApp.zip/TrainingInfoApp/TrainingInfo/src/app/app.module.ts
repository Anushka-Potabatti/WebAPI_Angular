import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from '@angular/common/http';

// For DatePicker
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// Components
import { AppComponent } from './app.component';
import { TrainingComponent } from './trainings/training/training.component';
import { TrainingListComponent } from './trainings/training-list/training-list.component';
import { TrainingsComponent } from './trainings/trainings.component';

// Services
import { TrainingService } from './training.service';

@NgModule({
  declarations: [
    AppComponent,
    TrainingComponent,
    TrainingsComponent,
    TrainingListComponent
  ],
  imports: [
    BrowserModule,    
    FormsModule,
    HttpClientModule,
    BsDatepickerModule.forRoot(),
    BrowserAnimationsModule
  ],
  providers: [TrainingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
