export class Training {
    TrainingId: number;
    Name: string;
    StartDate: Date;
    EndDate: Date;
}
