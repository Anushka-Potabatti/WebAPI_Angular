import { Component, OnInit } from '@angular/core';
import { TrainingService } from 'src/app/training.service';

@Component({
  selector: 'app-training-list',
  templateUrl: './training-list.component.html',
  styleUrls: ['./training-list.component.css']
})
export class TrainingListComponent implements OnInit {

  constructor(private service : TrainingService) { }

  // On every page load get training details from DB
  ngOnInit() {
    this.service.getAllTrainings();
  }

}
