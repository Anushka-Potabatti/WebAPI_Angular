import { Component, OnInit } from '@angular/core';
import { TrainingService} from 'src/app/training.service'
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-training',
  templateUrl: './training.component.html',
  styleUrls: ['./training.component.css']
})
export class TrainingComponent implements OnInit {

  constructor(private service: TrainingService) { }

  // Reset Form on every page load
  ngOnInit() {
    this.resetForm();
  }

  // On Confirm insert details into DB using WebAPI
  onConfirm(form: NgForm) {
    if (form.value.TrainingId == null)
      this.insertRecord(form);
  }

  // Post form data to Web API and Reset form so that new entry could be done
  insertRecord(form: NgForm) {
    this.service.postTrainingDetail(form.value);
    this.resetForm(form);
  }

  // Reset form 
  resetForm(form?: NgForm) {
    if (form != null)
      form.resetForm();
    this.service.formData = {
      TrainingId: null,
      Name: '',
      StartDate: null,
      EndDate: null
    }
  }


}
