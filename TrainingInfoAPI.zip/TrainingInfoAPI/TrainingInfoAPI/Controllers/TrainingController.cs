﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using TrainingInfoAPI.Models;

namespace TrainingInfoAPI.Controllers
{
    public class TrainingController : ApiController
    {

        private TrainingEntities _db;

        public TrainingController()
        {
            _db = new TrainingEntities();
        }

        // Get All Training Details
        public IHttpActionResult GetTrainingDetails()
        {
            try
            {
                var trainingDetails = _db.TrainingDetails.ToList();
                return Ok(trainingDetails);
            }
            catch (Exception ex) 
            {
                return BadRequest(ex.Message);
            }
        }

        // Save new Training Data in DB

        public IHttpActionResult PostTrainingDetail(TrainingDetail trainingDetail)
        {
            try
            {
                // Validate Start Date is before End Date
                string validationResult = validateDates(trainingDetail.StartDate, trainingDetail.EndDate);

                // If Start Date is before End Date Save Data to DB
                if(String.IsNullOrEmpty(validationResult))
                {
                    // Calculate difference between Start Date and End Date
                    TimeSpan span = trainingDetail.EndDate.Subtract(trainingDetail.StartDate);
                    using (var details = new TrainingEntities())
                    {
                        details.TrainingDetails.Add(new TrainingDetail()
                        {
                            StartDate = new DateTime(trainingDetail.StartDate.Year, trainingDetail.StartDate.Month, trainingDetail.StartDate.Day, 0,0,0),
                            EndDate = new DateTime(trainingDetail.EndDate.Year, trainingDetail.EndDate.Month, trainingDetail.StartDate.Day, 0, 0, 0),
                            Name = trainingDetail.Name,
                            TimeStamp = DateTime.Now
                        });
                        details.SaveChanges();
                    }
                    return Ok("Training Details are saved successfully.\nTraining duration (in days) : " + span.Days);
                }
                else
                {
                    // If Start Date is after End Date send Error
                    return BadRequest(validationResult);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Validate Dates
        private string validateDates(DateTime startDate, DateTime endDate) {
            if (startDate > endDate) {
                return ConfigurationManager.AppSettings["ErrorMessageForDate"].ToString();
            } else {                
                return String.Empty;
            }
        }
    }
}
